Dear {C_NAME},<br>
<br>
This is an invoice for clearing your account balance with our site, {SITENAME}.<br>
<br>
Your balance is: {BALANCE}<br>
<br>
Please [ <a href="{LINK}">click here</a> ] to access the payment page.