Dear {C_NAME},

This is an invoice for clearing your account balance with our site, {SITENAME}.

Your balance is: {BALANCE}

Please click on the link below to access to the payment page:
{LINK}