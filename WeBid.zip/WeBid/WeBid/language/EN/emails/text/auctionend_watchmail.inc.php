Dear {NAME},
This is an automatic response from Your Item Watch.
The auction closed which was on your Item Watch list.

Auction Title: {TITLE}
Auction URL: {URL}