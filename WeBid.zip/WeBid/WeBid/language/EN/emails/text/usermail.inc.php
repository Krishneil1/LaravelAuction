Complete Your {SITENAME} Registration!
Hello {C_NAME},
Thank you for signing up with {SITENAME} to complete your registration you must activate your account. Once you do that you are ready to start buying/selling on {SITENAME}

To activate your account, click the following link:
{CONFIRMURL}

If the link does not work:
Please email us at {ADMINMAIL}