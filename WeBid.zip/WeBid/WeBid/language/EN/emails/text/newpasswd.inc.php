Hi {REALNAME},
As you requested, we have created a new password for your account.

Your new password: {NEWPASS}

Use it to login to {SITENAME} and remember to change it to something you can remember.