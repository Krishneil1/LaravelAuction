Dear {S_NAME},
We're sorry, your auction you created on {SITENAME} has ended with no winner

Auction URL: {A_URL}
Auction Title: {A_TITLE}
Item #: {A_ID}
End date: {A_END}