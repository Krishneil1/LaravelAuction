Dear {C_NAME},
In order to begin selling and/or buying at {SITENAME}, your account must be
accepted by our site's administrator which is currently under review.

You will receive an e-mail shortly when your account is active.

Your information is below:

Full name: {C_NAME}
Username: {C_NICK}
<!-- IF C_ADDRESS ne '' -->
Address: {C_ADDRESS}
<!-- ENDIF -->
<!-- IF C_CITY ne '' -->
City: {C_CITY}
<!-- ENDIF -->
<!-- IF C_PROV ne '' -->
State: {C_PROV}
<!-- ENDIF -->
<!-- IF C_COUNTRY ne '' -->
Country: {C_COUNTRY}
<!-- ENDIF -->
<!-- IF C_ZIP ne '' -->
Zip: {C_ZIP}
<!-- ENDIF -->
Email: {C_EMAIL}