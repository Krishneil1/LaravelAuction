Dear {C_NAME},
Your bid of {C_BID} is no longer the leading bid on the following:

{A_TITLE}
Current price: {N_BID}
End date: {A_ENDS}

Goto My {SITENAME} {SITE_URL}user_menu.php