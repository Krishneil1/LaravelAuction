Dear {REALNAME},
This is your auction watch you've requested.
The following auction has opened matching your keyword(s): {KWORD}

Auction: {TITLE}
Auction URL: {URL}