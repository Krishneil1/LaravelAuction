Dear {SELLER_NICK},
This message is sent from {SITENAME}.

{SENDER_NAME} at {SENDER_EMAIL} has a question for you regarding your auction {TITLE}.

Question:
{SENDER_QUESTION}

Auction URL: {SITEURL}item.php?id={AID}