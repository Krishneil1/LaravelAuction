Congratulations, you won {A_QUANTITY} items!
Hello {W_NAME},

Congratulations you committed to buying the following item:{A_TITLE}

Your bid: {A_CURRENTBID}
Quantity: {A_QUANTITY}
End time: {A_ENDS}

Seller's Information
{S_NICK} {S_EMAIL}